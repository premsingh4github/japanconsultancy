<?php echo $__env->make('Admin.Layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('Admin.Layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('Admin.Layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('header'); ?>

<?php echo $__env->yieldContent('aside'); ?>
<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('footer'); ?>
