<?php $__env->startSection('aside'); ?>
    <div id="page-container" class="sidebar-o sidebar-dark enable-page-overlay side-scroll page-header-fixed">
        <!-- Side Overlay-->
        <aside id="side-overlay" class="font-size-sm">
            <!-- Side Header -->
            <div class="content-header border-bottom">
                <!-- Staff Avatar -->
                <a class="img-link mr-1" href="javascript:void(0)">
                    <img class="img-avatar img-avatar32" src="<?php echo e(asset('public/server')); ?>/assets/media/avatars/avatar10.jpg" alt="">
                </a>
                <!-- END Staff Avatar -->

                <!-- Staff Info -->
                <div class="ml-2">
                    <a class="link-fx text-dark font-w600" href="javascript:void(0)">Admin</a>
                </div>
                <!-- END Staff Info -->

                <!-- Close Side Overlay -->
                <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                <a class="ml-auto btn btn-sm btn-dual" href="javascript:void(0)" data-toggle="layout" data-action="side_overlay_close">
                    <i class="fa fa-fw fa-times text-danger"></i>
                </a>
                <!-- END Close Side Overlay -->
            </div>
            <!-- END Side Header -->

            <!-- Side Content -->
            
                
                
                    
                        
                            
                                
                            
                        
                        
                            
                                
                            
                        
                    
                    
                        
                        
                            
                            
                                
                                    
                                    
                                        
                                            
                                        
                                        
                                    
                                
                                
                                    
                                    
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                        
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                    
                                                
                                            
                                        
                                    
                                    
                                
                            
                            

                            
                            
                                
                                    
                                    
                                        
                                            
                                        
                                        
                                    
                                
                                
                                    
                                    
                                        
                                            
                                                
                                                    
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                    
                                    
                                
                            
                            

                            
                            
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                            
                                                
                                            
                                            
                                                
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                                
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                                
                                                
                                            
                                            
                                                
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                                
                                                
                                            
                                        
                                    
                                    
                                
                            
                            
                        
                        

                        
                        
                            
                                
                                
                                    
                                        
                                            
                                            
                                        
                                        
                                            
                                            
                                        
                                    
                                
                                

                                
                                
                                    
                                        
                                            
                                        
                                        
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                    
                                
                                

                                
                                
                                    
                                        
                                            
                                        
                                        
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                                    

                                    
                                    
                                        
                                            
                                        
                                    
                                    
                                
                                
                            
                        
                        
                    
                
                
            
            <!-- END Side Content -->
        </aside>
        <!-- END Side Overlay -->

        <!-- Sidebar -->
        <nav id="sidebar" aria-label="Main Navigation">
            <!-- Side Header -->
            <div class="content-header bg-white-5">
                <!-- Logo -->
                <a class="font-w600 text-dual" href="<?php echo e(url('')); ?>" title="Redirect to home page">
                    <i class="fa fa-circle-notch text-primary"></i>
                    <span class="smini-hide">
                            <span class="font-w700 font-size-h6">Chubi</span> <span class="font-w400" style="color:#5c80d1;">Project</span>
                        </span>
                </a>
                <!-- END Logo -->

                <!-- Options -->
                <div>
                    <!-- Color Variations -->
                    <div class="dropdown d-inline-block ml-3">
                        <a class="text-dual font-size-sm" id="sidebar-themes-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="si si-drop"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right font-size-sm smini-hide border-0" aria-labelledby="sidebar-themes-dropdown">
                            <!-- Color Themes -->
                            <!-- Layout API, functionality initialized in Template._uiHandleTheme() -->
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="default" href="#">
                                <span>Default</span>
                                <i class="fa fa-circle text-default"></i>
                            </a>
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="<?php echo e(asset('public/server')); ?>/assets/css/themes/amethyst.min.css" href="#">
                                <span>Amethyst</span>
                                <i class="fa fa-circle text-amethyst"></i>
                            </a>
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="<?php echo e(asset('public/server')); ?>/assets/css/themes/city.min.css" href="#">
                                <span>City</span>
                                <i class="fa fa-circle text-city"></i>
                            </a>
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="<?php echo e(asset('public/server')); ?>/assets/css/themes/flat.min.css" href="#">
                                <span>Flat</span>
                                <i class="fa fa-circle text-flat"></i>
                            </a>
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="assets/css/themes/modern.min.css" href="#">
                                <span>Modern</span>
                                <i class="fa fa-circle text-modern"></i>
                            </a>
                            <a class="dropdown-item d-flex align-items-center justify-content-between" data-toggle="theme" data-theme="<?php echo e(asset('public/server')); ?>/assets/css/themes/smooth.min.css" href="#">
                                <span>Smooth</span>
                                <i class="fa fa-circle text-smooth"></i>
                            </a>
                            <!-- END Color Themes -->

                            <div class="dropdown-divider"></div>

                            <!-- Sidebar Styles -->
                            <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                            <a class="dropdown-item" data-toggle="layout" data-action="sidebar_style_light" href="#">
                                <span>Sidebar Light</span>
                            </a>
                            <a class="dropdown-item" data-toggle="layout" data-action="sidebar_style_dark" href="#">
                                <span>Sidebar Dark</span>
                            </a>
                            <!-- Sidebar Styles -->

                            <div class="dropdown-divider"></div>

                            <!-- Header Styles -->
                            <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                            <a class="dropdown-item" data-toggle="layout" data-action="header_style_light" href="#">
                                <span>Header Light</span>
                            </a>
                            <a class="dropdown-item" data-toggle="layout" data-action="header_style_dark" href="#">
                                <span>Header Dark</span>
                            </a>
                            <!-- Header Styles -->
                        </div>
                    </div>
                    <!-- END Themes -->

                    <!-- Close Sidebar, Visible only on mobile screens -->
                    <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                    <a class="d-lg-none text-dual ml-3" data-toggle="layout" data-action="sidebar_close" href="javascript:void(0)">
                        <i class="fa fa-times"></i>
                    </a>
                    <!-- END Close Sidebar -->
                </div>
                <!-- END Options -->
            </div>
            <!-- END Side Header -->

            <!-- Side Navigation -->
            <div class="content-side content-side-full">
                <ul class="nav-main">
                    <li class="nav-main-item">
                        <a class="nav-main-link <?php if(request()->segment('2') ==''){ echo 'active' ;} ?>" href="<?php echo e(url('login')); ?>">
                            <i class="nav-main-link-icon si si-speedometer"></i>
                            <span class="nav-main-link-name">Admin Panel / 管理ダッシュボード </span>
                        </a>
                    </li>
                    <li class="nav-main-heading ">User Manager / ユーザー管理</li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu <?php if(request()->segment('2') =='superAdmin' || request()->segment('2') =='generalAdmin' || request()->segment('2') =='moderator'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-energy"></i>
                            <span class="nav-main-link-name">User Control / ウーザーコントロール</span>
                        </a>
                    </li>
                    <li class="nav-main-heading ">Student/Teacher Manager / 学生/先生管理</li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu  <?php if(request()->segment('2') =='clients' || request()->segment('2') =='createClient'){ echo 'active' ;} ?>" data-toggle="submenu"  href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Teachers / 先生</span>
                        </a>
                    </li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='add_student' || request()->segment('2') =='list_student' || request()->segment('2') =='section_wise_student'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Students / 学生</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='list_student'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/list_student')); ?>">
                                    <span class="nav-main-link-name">List All Students</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='add_student'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/add_student')); ?>">
                                    <span class="nav-main-link-name">Add New Students</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='section_wise_student'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/section_wise_student')); ?>">
                                    <span class="nav-main-link-name">Section Wise Students</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-heading ">Class/Batch Manager / クラス管理 /li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='list_section' || request()->segment('2') =='add_section' || request()->segment('2') =='add_section' || request()->segment('2') =='class_section'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Residensal C.Time</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='list-residensal'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/list-residensal')); ?>">
                                    <span class="nav-main-link-name">List Residensal C.Time</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='add-residensal'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/add-residensal')); ?>">
                                    <span class="nav-main-link-name">Add Residensal C.Time</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='list_subject' || request()->segment('2') =='add_subject' || request()->segment('2') =='batch_wise_subject'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Subjects / 学部</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='list_subject'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/list_subject')); ?>">
                                    <span class="nav-main-link-name">List Exist Subject</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='add_subject'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/add_subject')); ?>">
                                    <span class="nav-main-link-name">Add New Subject</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='batch_wise_subject'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/batch_wise_subject')); ?>">
                                    <span class="nav-main-link-name">Batch Wise Subject</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='list_record' || request()->segment('2') =='add_record'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Class/Batch / クラス</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='list_record'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/list_record')); ?>">
                                    <span class="nav-main-link-name">List Class/Batch</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='add_record'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/add_record')); ?>">
                                    <span class="nav-main-link-name">Add Record</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='list_section' || request()->segment('2') =='add_section' || request()->segment('2') =='add_section' || request()->segment('2') =='class_section'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Section / セクション</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='list_section'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/list_section')); ?>">
                                    <span class="nav-main-link-name">List Exist Section</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='add_section'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/add_section')); ?>">
                                    <span class="nav-main-link-name">Add New Section</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='class_section'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/class_section')); ?>">
                                    <span class="nav-main-link-name">Class Wise Section</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-heading ">Days/Holiday Manager</li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='holiday' || request()->segment('2') =='new_holiday'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Holiday</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='holiday'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/holiday')); ?>">
                                    <span class="nav-main-link-name">List Exist Holiday</span>
                                </a>
                            </li>
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='new_holiday'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/new_holiday')); ?>">
                                    <span class="nav-main-link-name">Add New Holiday</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-item">
                        <a class="nav-main-link nav-main-link-submenu   <?php if(request()->segment('2') =='holiday' || request()->segment('2') =='new_holiday'){ echo 'active' ;} ?>" data-toggle="submenu" aria-haspopup="true" aria-expanded="false" href="#">
                            <i class="nav-main-link-icon si si-badge"></i>
                            <span class="nav-main-link-name">Section Wise Days</span>
                        </a>
                        <ul class="nav-main-submenu">
                            <li class="nav-main-item">
                                <a class="nav-main-link <?php if(request()->segment('2') =='section_day'){ echo 'active' ;} ?>" href="<?php echo e(url('admin/section_day')); ?>">
                                    <span class="nav-main-link-name">Class Section Days</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-main-heading ">Attendance</li>
                    <li class="nav-main-item">
                        <a class="nav-main-link   <?php if(request()->segment('2') =='holiday' || request()->segment('2') =='new_holiday'){ echo 'active' ;} ?>" href="<?php echo e(url('attendance_list')); ?>">
                            <span class="nav-main-link-name">Attendance</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- END Side Navigation -->
        </nav>
        <!-- END Sidebar -->

        <!-- Header -->
        <header id="page-header">
            <!-- Header Content -->
            <div class="content-header">
                <!-- Left Section -->
                <div class="d-flex align-items-center">
                    <!-- Toggle Sidebar -->
                    <!-- Layout API, functionality initialized in Template._uiApiLayout()-->
                    <button type="button" class="btn btn-sm btn-dual mr-2 d-lg-none" data-toggle="layout" data-action="sidebar_toggle">
                        <i class="fa fa-fw fa-bars"></i>
                    </button>
                    <!-- END Toggle Sidebar -->

                    <!-- Toggle Mini Sidebar -->
                    <!-- Layout API, functionality initialized in Template._uiApiLayout()-->
                    <button type="button" class="btn btn-sm btn-dual mr-2 d-none d-lg-inline-block" data-toggle="layout" data-action="sidebar_mini_toggle">
                        <i class="fa fa-fw fa-ellipsis-v"></i>
                    </button>
                    <!-- END Toggle Mini Sidebar -->

                    <!-- Apps Modal -->
                    <!-- Opens the Apps modal found at the bottom of the page, after footer’s markup -->
                    
                        
                    
                    <!-- END Apps Modal -->

                    <!-- Open Search Section (visible on smaller screens) -->
                    <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                    <button type="button" class="btn btn-sm btn-dual d-sm-none" data-toggle="layout" data-action="header_search_on">
                        <i class="si si-magnifier"></i>
                    </button>
                    <!-- END Open Search Section -->

                    <!-- Search Form (visible on larger screens) -->
                    <form class="d-none d-sm-inline-block" action="be_pages_generic_search.html" method="POST">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control form-control-alt" placeholder="Search.." id="page-header-search-input2" name="page-header-search-input2">
                            <div class="input-group-append">
                                    <span class="input-group-text bg-body border-0">
                                        <i class="si si-magnifier"></i>
                                    </span>
                            </div>
                        </div>
                    </form>
                    <!-- END Search Form -->
                </div>
                <!-- END Left Section -->

                <!-- Right Section -->
                <div class="d-flex align-items-center">
                    <!-- Staff Dropdown -->
                    <div class="dropdown d-inline-block ml-2">
                        <button type="button" class="btn btn-sm btn-dual" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="rounded" src="<?php echo e(asset('public/server')); ?>/assets/media/avatars/avatar10.jpg" alt="Header Avatar" style="width: 18px;">
                            <span class="d-none d-sm-inline-block ml-1"><?php echo e(Auth::user()->name); ?></span>
                            <i class="fa fa-fw fa-angle-down d-none d-sm-inline-block"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right p-0 border-0 font-size-sm" aria-labelledby="page-header-user-dropdown">
                            <div class="p-3 text-center bg-primary">
                                <img class="img-avatar img-avatar48 img-avatar-thumb" src="assets/media/avatars/avatar10.jpg" alt="">
                            </div>
                            <div class="p-2">
                                <h5 class="dropdown-header text-uppercase">User Options</h5>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="">
                                    <span>Inbox</span>
                                    <span>
                                            <span class="badge badge-pill badge-primary"></span>
                                            <i class="si si-envelope-open ml-1"></i>
                                        </span>
                                </a>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="be_pages_generic_profile.html">
                                    <span>Profile</span>
                                    <span>
                                            <span class="badge badge-pill badge-success">1</span>
                                            <i class="si si-user ml-1"></i>
                                        </span>
                                </a>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="javascript:void(0)">
                                    <span>Settings</span>
                                    <i class="si si-settings"></i>
                                </a>
                                <div role="separator" class="dropdown-divider"></div>
                                <h5 class="dropdown-header text-uppercase">Actions</h5>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="op_auth_lock.html">
                                    <span>Lock Account</span>
                                    <i class="si si-lock ml-1"></i>
                                </a>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="<?php echo e(url('logout')); ?>">
                                    <span>Log Out</span>
                                    <i class="si si-logout ml-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- END Staff Dropdown -->

                    <!-- Notifications Dropdown -->
                    <div class="dropdown d-inline-block ml-2">
                        <button type="button" class="btn btn-sm btn-dual" id="page-header-notifications-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="si si-bell"></i>
                            <span class="badge badge-primary badge-pill"></span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0 border-0 font-size-sm" aria-labelledby="page-header-notifications-dropdown">
                            <div class="p-2 bg-primary text-center">
                                <h5 class="dropdown-header text-uppercase text-white">Notifications</h5>
                            </div>
                            
                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                    
                                                
                                            
                                        
                            
                            <div class="p-2 border-top">
                                <a class="btn btn-sm btn-light btn-block text-center" href="javascript:void(0)">
                                    <i class="fa fa-fw fa-arrow-down mr-1"></i> Load More..
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- END Notifications Dropdown -->

                    <!-- Toggle Side Overlay -->
                    <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                    <button type="button" class="btn btn-sm btn-dual ml-2" data-toggle="layout" data-action="side_overlay_toggle">
                        <i class="fa fa-fw fa-list-ul fa-flip-horizontal"></i>
                    </button>
                    <!-- END Toggle Side Overlay -->
                </div>
                <!-- END Right Section -->
            </div>
            <!-- END Header Content -->

            <!-- Header Search -->
            <div id="page-header-search" class="overlay-header bg-white">
                <div class="content-header">
                    <form class="w-100" action="be_pages_generic_search.html" method="POST">
                        <div class="input-group input-group-sm">
                            <div class="input-group-prepend">
                                <!-- Layout API, functionality initialized in Template._uiApiLayout() -->
                                <button type="button" class="btn btn-danger" data-toggle="layout" data-action="header_search_off">
                                    <i class="fa fa-fw fa-times-circle"></i>
                                </button>
                            </div>
                            <input type="text" class="form-control" placeholder="Search or hit ESC.." id="page-header-search-input" name="page-header-search-input">
                        </div>
                    </form>
                </div>
            </div>
            <!-- END Header Search -->

            <!-- Header Loader -->
            <!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->
            <div id="page-header-loader" class="overlay-header bg-white">
                <div class="content-header">
                    <div class="w-100 text-center">
                        <i class="fa fa-fw fa-circle-notch fa-spin"></i>
                    </div>
                </div>
            </div>
            <!-- END Header Loader -->
        </header>
        <!-- END Header -->
<?php $__env->stopSection(); ?>