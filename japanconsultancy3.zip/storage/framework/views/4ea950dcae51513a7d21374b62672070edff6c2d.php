<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">
        <div class="content">
            <!-- Dynamic Table with Export Buttons -->
            <div class="block">
                <div class="block-header">
                    <h3 class="block-title">Holiday List</h3>
                    <div class="pull-right">
                        <a href="<?php echo e(url('admin/new_holiday')); ?>" class="btn btn-primary btn-sm"><i class=" fa fa-plus"></i> Add Holiday</a>
                    </div>
                </div>
                <div class="block-content block-content-full">
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <p class="font-size-sm text-muted">
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul  class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                            </p>
                    </div>
                    <!-- DataTables init on table by adding .js-dataTable-buttons class, functionality is initialized in js/pages/be_tables_datatables.min.js which was auto compiled from _es6/pages/be_tables_datatables.js -->
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-full">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Date</th>
                            <th>Title</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $list_holiday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($holiday->date); ?></td>
                                <td><?php echo e($holiday->title); ?></td>
                                <td><?php echo $holiday->description; ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/holiday/edit=').$holiday->id); ?>"><span class="badge badge-info">Edit</span></a>
                                    <a href=""><span class="badge badge-danger">Delete</span></a>
                                </td>
                            </tr>
                            <<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END Dynamic Table with Export Buttons -->
        </div>
    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>