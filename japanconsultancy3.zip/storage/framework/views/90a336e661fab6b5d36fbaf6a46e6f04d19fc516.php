<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">
        <div class="content">
            <div class="block">
                <div class="block-header">
                    <h3 class="block-title">Create Holiday</h3>
                    <div class="pull-right">
                        <a href="<?php echo e(url('admin/holiday')); ?>" class="btn btn-primary btn-sm"><i class=" fa fa-list"></i> List Holiday</a>
                    </div>
                </div>
                <div class="block-content block-content-full">
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <p class="font-size-sm text-muted">
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul  class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                            </p>
                    </div>

                    <form action="<?php echo e(url('admin/post_holiday')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="form-group col-sm-2">
                                <label for="date">Date</label>
                            </div>
                            <div class="form-group col-sm-4">
                                <input type="text" class="js-datepicker form-control" id="example-datepicker3" name="date" data-week-start="1" data-autoclose="true" data-today-highlight="true" data-date-format="yyyy-mm-dd" placeholder="yyyy-mm-dd">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="title">Title</label>
                            </div>
                            <div class="form-group col-sm-4">
                                <input type="text" class="form-control" name="title">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="description">Description</label>
                            </div>
                            <div class="form-group col-sm-10">
                                <textarea type="text" id="js-ckeditor" class="form-control" name="description"></textarea>
                            </div>
                            <div class="form-group col-sm-3">
                                <button type="submit" class="btn btn-primary">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>