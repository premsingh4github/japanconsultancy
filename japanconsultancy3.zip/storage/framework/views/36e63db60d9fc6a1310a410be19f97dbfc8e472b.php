<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">

        <!-- Hero -->
        <div class="bg-body-light">
            <div class="content content-full">
                <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                    <h1 class="flex-sm-fill h3 my-2">
                        Class/Batch Manager
                    </h1>
                    <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-alt">
                            <li class="breadcrumb-item">Class/Batch Manager</li>
                            <li class="breadcrumb-item" aria-current="page">
                                <a class="link-fx" href="<?php echo e(url('admin/add_record')); ?>">Add Record</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="col-sm-12 col-md-12 col-xs-12">
                    <p class="font-size-sm text-muted">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                        </p>
                </div>
            </div>
        </div>
        <!-- END Hero -->
        <!-- Page Content -->
        <div class="content">
            <div class="row">
                <div class="col-sm-3">
                    <h4>Class Room Status</h4>
                    <table class="table table-responsive table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Class Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $class_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$clasRooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($clasRooms->name); ?></td>
                            <td>
                                <a href="" class="btn btn-primary btn-sm">Edit</a>
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-sm-3">
                    <h4>Batch Year Status</h4>
                    <table class="table table-responsive table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Batch Year</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $batch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$batches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($batches->name); ?></td>
                                <td>
                                    <a href="" class="btn btn-primary btn-sm">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
                <div class="col-sm-6">
                    <h4>Class/Batch Group</h4>
                    <table class="table table-responsive table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>SN</th>
                            <th>Class Name</th>
                            <th>Batch Year</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $class_batch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$classBatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($classBatch->class_room->name); ?></td>
                            <td><?php echo e($classBatch->batch->name); ?></td>
                            <td>
                                <a href="" class="btn btn-primary btn-sm">Edit</a>
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- END Page Content -->

    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>