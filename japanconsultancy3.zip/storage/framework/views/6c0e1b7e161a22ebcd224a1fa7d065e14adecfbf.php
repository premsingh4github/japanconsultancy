<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">

        <!-- Hero -->
        <div class="bg-body-light">
            <div class="content content-full">
                <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                    <h1 class="flex-sm-fill h3 my-2">
                        Edit Section
                    </h1>
                    <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-alt">
                            <li class="breadcrumb-item">Edit Section</li>
                            <li class="breadcrumb-item" aria-current="page">
                                <a class="link-fx" href="<?php echo e(url('admin/add_section')); ?>">Add Section</a>
                            </li>
                            <li class="breadcrumb-item" aria-current="page">
                                <a class="link-fx" href="<?php echo e(url('admin/list_section')); ?>">List Section</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="col-sm-12 col-md-12 col-xs-12">
                    <p class="font-size-sm text-muted">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                        </p>
                </div>
            </div>
        </div>
        <!-- END Hero -->
        <!-- Page Content -->
        <div class="content">
            <!-- Partial Table -->
            <div class="block" style="padding:20px;">
                <form action="" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="form-group col-sm-12">
                            <label for="student_name">Section Name<font color="#ff0000">*</font></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($subject->name); ?>">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                        <div class="form-group col-sm-4">
                            <button type="submit" class="btn  btn-success">Update</button>
                        </div>
                    </div>

                </form>
            </div>
            <!-- END Partial Table -->
        </div>
        <!-- END Page Content -->

    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>