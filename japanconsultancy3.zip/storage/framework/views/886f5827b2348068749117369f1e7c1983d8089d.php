<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">

        <!-- Hero -->
        <div class="bg-body-light">
            <div class="content content-full">
                <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                    <h1 class="flex-sm-fill h3 my-2">
                        Attendance
                    </h1>
                    <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-alt">
                            <li class="breadcrumb-item">Student Attendance</li>
                            <li class="breadcrumb-item" aria-current="page">
                                <a class="link-fx" href="<?php echo e(url('admin/add_record')); ?>">Export</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="col-sm-12 col-md-12 col-xs-12">
                    <p class="font-size-sm text-muted">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                        </p>
                </div>
            </div>
        </div>
        <!-- END Hero -->
        <!-- Page Content -->
        <div class="content">
            <!-- Customers and Latest Orders -->
            <div class="row row-deck">
                <!-- Latest Orders -->
                <div class="col-lg-12">
                    <div class="block block-mode-loading-oneui">
                        <div class="block-header border-bottom">
                            <h3 class="block-title">Students Attendance</h3>
                            <div class="block-options">
                                <button type="button" class="btn-block-option" data-toggle="block-option" data-action="state_toggle" data-action-mode="demo">
                                    <i class="si si-refresh"></i>
                                </button>
                                <button type="button" class="btn-block-option">
                                    <i class="si si-settings"></i>
                                </button>
                            </div>
                        </div>
                        <div class="block-content block-content-full">

                            

                            <table border="1" bgcolor="#fff">

                                <th>NO</th>
                                <th>Student No</th>
                                <th>Image</th>
                                <th>Student Name</th>
                                <th>Japanese Name</th>
                                <th>Sex</th>
                                <th>Day Period</th>
                                <th><P>月 Month<br>
                                        03</p></th>
                                <th><P>火(Tue)<br>
                                        04</p></th>
                                <th><P>水 (wed)<br>
                                        05</p></th>
                                <th><P>木 (Thu)<br>
                                        06</p></th>
                                <th><P>金 (Frid)<br>
                                        07</p></th>

                                <th><P>月 (Mon)<br>
                                        08</p></th>
                                <th><P>火 (Tue)<br>
                                        09</p></th>
                                <th><P>水 (Wed)<br>
                                        10</p></th>
                                <th><P>木 (Thu)<br>
                                        11</p></th>
                                <th><P>金 (Frid)<br>
                                        12</p></th>

                                <th><P>月 (Mon)<br>
                                        13</p></th>
                                <th><P>火 (Tue)<br>
                                        14</p></th>
                                <th><P>水 (Wed)<br>
                                        15</p></th>
                                <th><P>木 (Thu)<br>
                                        16</p></th>
                                <th><P>金 (Frid)<br>
                                        17</p></th>

                                <th><P>月<br>
                                        18</p></th>
                                <th><P>火<br>
                                        19</p></th>
                                <th><P>水<br>
                                        20</p></th>
                                <th><P>木<br>
                                        21</p></th>
                                <th><P>金<br>
                                        22</p></th>

                                <th><P>月<br>
                                        23</p></th>
                                <th><P>火<br>
                                        24</p></th>
                                <th><P>水<br>
                                        25</p></th>
                                <th><P>木<br>
                                        26</p></th>
                                <th><P>金<br>
                                        27</p></th>

                                <th><P>月<br>
                                        28</p></th>

                                </tr>
                                <td>1</td>
                                <td>1234q3</td>
                                <td><img src="" alt=""></td>
                                <td>Ganesh</td>
                                <td>jp name</td>
                                <td>M</td>
                                <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

                                <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

                                <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>

 <td><input type="radio" name="group1" value="present[0]">A1</input><br>
                                    <input type="radio" name="group2" value="Absent[0]">A2</input><br>
                                    <input type="radio" name="group3" value="Absent[0]">A3</input><br>
                                    <input type="radio" name="group4" value="Absent[0]">A4</input>
                                </td>




                            </table>
                            <tr><td><input type="submit" name="submit" value="Export CSV"/></td></tr>
                            


                            
                                
                                
                                    
                                        
                                    
                                
                                
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                

                                
                                    
                                    
                                        
                                        
                                        
                                            
                                                
                                            
                                                
                                            

                                        
                                        
                                        
                                        
                                        
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                           
                                               
                                                   
                                               
                                           
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                            
                                        
                                        

                                        
                                            
                                            
                                        


                                    
                                
                                
                            
                        </div>
                    </div>
                </div>
                <!-- END Latest Orders -->
            </div>
            <!-- END Customers and Latest Orders -->
        </div>
        <!-- END Page Content -->

    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>