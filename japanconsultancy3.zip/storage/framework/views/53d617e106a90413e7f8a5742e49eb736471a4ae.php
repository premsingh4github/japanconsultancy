<?php $__env->startSection('body'); ?>
    <!-- Main Container -->
    <main id="main-container">

        <!-- Hero -->
        <div class="bg-body-light">
            <div class="content content-full">
                <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                    <h1 class="flex-sm-fill h3 my-2">
                        Attendance
                    </h1>
                    <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-alt">
                            <li class="breadcrumb-item">Student Attendance</li>
                            <li class="breadcrumb-item" aria-current="page">
                                <a class="link-fx" href="<?php echo e(url('admin/add_record')); ?>">Export</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="col-sm-12 col-md-12 col-xs-12">
                    <p class="font-size-sm text-muted">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                        </p>
                </div>
            </div>
        </div>
        <!-- END Hero -->
        <!-- Page Content -->
        <div class="content">
            <!-- Customers and Latest Orders -->
            <div class="row row-deck">
                <!-- Latest Orders -->
                <div class="col-lg-12">
                    <div class="block block-mode-loading-oneui">
                        <div class="block-header border-bottom">
                            <h3 class="block-title">Students Attendance</h3>
                            <div class="block-options">
                                <button type="button" class="btn-block-option" data-toggle="block-option" data-action="state_toggle" data-action-mode="demo">
                                    <i class="si si-refresh"></i>
                                </button>
                                <button type="button" class="btn-block-option">
                                    <i class="si si-settings"></i>
                                </button>
                            </div>
                        </div>
                        <div class="block-content block-content-full">
                            <table class="table table-striped table-hover table-borderless table-vcenter font-size-sm mb-0">
                                <thead  >
                                <style>
                                    .block-content .thead-dark th{
                                        text-transform: none;
                                    }
                                </style>
                                <tr>
                                    <td colspan="6"> &nbsp;</td>
                                    <td > 曜日(DAYS)</td>
                                    <td > 月(MON))</td>
                                </tr>
                                <tr>
                                    <th >SN</th>
                                    <th >Student NO.</th>
                                    <th class="font-w700">顔写真(PHOTO)</th>
                                    <th class="font-w700">名前(NAME)</th>
                                    <th class="font-w700">フリガナ(JAPANESE NAME)</th>
                                    <th class="font-w700">性別(SEX)</th>
                                    <th class="font-w700">時限(PERIOD)</th>
                                    <th class="font-w700">ID</th>
                                    <th class="font-w700">Student Class/Batch</th>
                                    <th class="font-w700">Address</th>
                                    <th class="font-w700">Gender</th>
                                    <th class="font-w700">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $attendaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $students = $value->student ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($value->student->unique_id); ?></td>
                                        <td>
                                            <?php if(isset($students->photo)): ?>
                                                <img src="<?php echo e(url('public/photos').'/'.$students->photo); ?>" alt="" style="background-color: #fff; width:65px;  border: 2px solid lightgrey; border-radius: 50%; padding:2px;">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('public/photos/avatar.jpg')); ?>" alt="" class="" style="background-color: #fff; width:65px;  border: 2px solid lightgrey; border-radius: 50%; padding:2px;">
                                            <?php endif; ?>

                                        </td>
                                        <td><?php echo e($students->last_student_name); ?> <?php echo e($students->first_student_name); ?></td>
                                        <td><?php echo e($students->last_student_japanese_name); ?> <?php echo e($students->first_student_japanese_name); ?></td>
                                        <td>
                                        <?php if($students->student_sex == 'm'): ?>Male
                                            <?php elseif($students->student_sex == 'f'): ?>Female
                                            <?php else: ?>
                                            Others
                                        <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($students->classBatchSections); ?>

                                           <table>
                                               <tr>
                                                   <td>A1</td>
                                               </tr>
                                           </table>
                                        </td>
                                        
                                        
                                        
                                        
                                        
                                            
                                        
                                            
                                        
                                        

                                        
                                            
                                            
                                        


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- END Latest Orders -->
            </div>
            <!-- END Customers and Latest Orders -->
        </div>
        <!-- END Page Content -->

    </main>
    <!-- END Main Container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>