<?php
return [
    'marital_statuses'=>[
        'u'=>'Unmarried',
        'm'=>'Married'
    ],
    'gender_types'=>[
        'm'=>'Male',
        'f'=>'Female',
        'o'=>'Other'
    ],
];