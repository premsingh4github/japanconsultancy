<?php
/**
 * Created by PhpStorm.
 * User: ganesh
 * Date: 2/17/2019
 * Time: 6:09 PM
 */
return[
    /*admin Left menu*/
    'Graduation_Prospect_Certificate'=>'Graduation Prospect Certificate',
    'Graduation_Certificate'=>'Graduation Certificate',
    'Certificate_of_Student_Status'=>'Certificate of Student Status',
    'Download'=>'Download',

    'Period_Time_Update'=>'Period Time Update',

    'Admin_Panel'=>'Admin Panel',
    'admin'=>'Admin',
    'User_Manager'=>'USER MANAGER',
    'User_controller'=>'User Control',
    'STUDENT_TEACHER_MANAGER'=>'STUDENT/TEACHER MANAGER',
    'Teachers'=>'Teachers',
    'MANAGER'=>'MANAGER',
    'Students'=>'Students',
    'Subject_Record'=>'Subject Record',
    'Subject_Name'=>'Subject Name',
    'Subject_Type'=>'Subject Type',
    'CLASS_BATCH_MANAGER'=>'CLASS BATCH MANAGER',

    'Residensal_Card_Time'=>'Residensal Card Time',
    'List_Card_Time'=>'List Residensal Card Time',
    'Add_Card_Time'=>'Add Residensal Card Time',
    'Residential_card_time_Period'=>'Residential card time Period',
    'section_record'=>'section record',

    'List_All_Students'=>'List All Students',
    'Add_New_Students'=>'Add New Students',
    'Students_1st_Immigration'=>'1st Immigration',
    'Students_2nd_Immigration'=>'2nd Immigration',
    'Section_Wise_Students1'=>'Section Wise (Add)',
    'Section_Wise_Students2'=>'Section Wise (Edit)',

    'Enter_student_number'=>'Enter student number',
    'student_year'=>'student year',
    'students_record'=>'students record',

    'Add_New_Subject'=>'Add New Subject',
    'List_Exist_Subject'=>' List Exist Subject',
    'Batch_Wise_Subject'=>'Batch Wise Subject',

    'List_Class_Batch'=>'List Class/Batch',
    'Add_Record'=>'Add Record',

    'List_Exist_Section'=>'List Exist Section',
    'Add_New_Section'=>'Add New Section',
    'Class_Wise_Section'=>'Class Wise Section',
    'Section_Wise_Period'=>'Section Wise Period',
    'Create_Section_Wise_Period'=>'Create Section Wise Period',
    'Class_Section_Days'=>'Class Section Days',
    'class_room_status'=>'class room status',
    'Class_Name'=>'Class Name',
    'Section_Wise_Days'=>'Section Wise Days',
    'Section_Record'=>'Section Record',
    'Edit_Section'=>'Edit Section',
    'Update_Section'=>'Update Section',

    'Attendance'=>'Attendance',
    'QR_Scanner'=>'QR Scanner',
    'List_Attendance'=>'List Attendance',

    'Days_Holiday_Manager'=>'Days/Holiday Manager',
    'Holiday'=>'Holiday',
    'List_Exist_Holiday'=>'List Exist Holiday',
    'Add_New_Holiday'=>'Add New Holiday',
    'Create_Holiday'=>'Create Holiday',
    'Create_Section'=>'Create Section',





    'Subjects'=>'Subjects',
    'Class_Batch'=>'Class/Batch',
    'Class_batch_manger'=>'Class/batch manger',
    'batch_year_status'=>'Batch year status',
    'Section'=>'Section',
    /*admin Left menu*/

    /*Class Batch manager*/
    'Add_Class_Batch'=>'Add Class Batch',
    'Create_Class_Room'=>'Create Class Room',
    'Create_Class'=>'Create_Class',
    'Allready_Listed_Class'=>'Allready Listed Class',
    'Create_Batch_Year'=>'Create Batch Year',
    'Create_Batch'=>'Create Batch',
    'Allready_Listed_Batch Year'=>'Allready Listed Batch Year',
    'Create_Group'=>'Create Group',
    'Select_Class'=>'Select Class',
    'Select_Batch'=>'Select Batch',
    'Allready_Listed_Batch_Wise_Class'=>'Allready Listed Batch Wise Class',
    'Batch_Year'=>'Batch Year',
    'Class_Batch_Group'=>'Class Batch Group',
    'Student_In_Batch'=>'Student In Batch',
    /*Class Batch manager*/
    /*View Teacher*/
    'Name_of_Teacher'=>'Name of Teacher',
    'Teacher_Profile'=>'Teacher Profile',
    'Save_Teacher'=>'Save Teacher',
    'List_of_Teacher'=>'List of Teacher',
    'Add_New_Teacher'=>'Add New Teacher',
    'About_Teacher'=>'About Teacher',
    'Subject_Teacher'=>'Subject Teacher',
    /*View Teacher end*/

    'Details'=>'Details',
    'Copy'=>'Copy',
    'Print'=>'Print',
    'Pdf'=>'Pdf',
    'CSV'=>'CSV',
    'No_data_avilable_in_table'=>'No data avilable in table',
    'Choose_file'=>'Choose file',
    'No_file_choosen'=>'No file choosen',
    'SN'=>'SN',
    'Choose'=>'Choose',
    'Student_Attendance_Report'=>'Student Attendance Report',



    'Morning'=>'Morning',
    'Evening'=>'Evening',
    'create_class_room'=>'Create lass room',
    'create_class'=>'Create class',
    'class_shift'=>'クラスシフト',
    'Start_date'=>'Start date',
    'End_date'=>'End date',
    'Start_Time'=>'Start Time',
    'End_Time'=>'End Time',
    'Title'=>'Title',
    'Description'=>'Description',
    'Search'=>'Search',
    'Period_Name'=>'Period Name',


    /*dashboard*/
    'Language'=>'Language',
    'Japanese'=>'Japanese',
    'English'=>'English',
    'Admin_Dashboard'=>'Admin Dashboard',
    'Welcome_Administrator'=>'Welcome Administrator',
    'Total_Students'=>'Total Students',
    'Absent_Student'=>'Absent Student',
    'Total_Users'=>'Total Users',
    'Notifications'=>'Notifications',
    'Load_More'=>'Load More',
    'Logout'=>'Logout',

    'Subject_Manager'=>'Subject Manager',
    'STUDENTS_RECORD'=>'STUDENTS RECORD',
    'TOTAL_STUDENT'=>'TOTAL STUDENT',
    'S_N'=>'SN',
    'Photo'=>'Photo',
    'Download'=>'Download',
    'Residential_ID'=>'Residential ID',
    'Student_Name'=>'Student Name',
    'Japanese_Name'=>'Japanese Name',
    'Student_ID_No'=>'Student ID No.',
    'Student_Class_Batch'=>'Student Class/Batch',
//    'Student_Class_Batch'=>'Student Class/Batch',
    'Address'=>'Address',
    'Gender	'=>'Gender	',
    'Action'=>'Action',
    'Edit'=>'Edit',
    'Delete'=>'Delete',
    'SUBJECT_NAME'=>'SUBJECT NAME',
    'SUBJECT_TYPE'=>'SUBJECT TYPE',
    /*Dashboard end */

    /*Add Student */
    'English_Last_Name'=>'English Last Name',
    'English_First_Name'=>'English First Name',
    'Japanese_Last_Name'=>'Japanese Last Name',
    'Japanese_First_Name'=>'Japanese First Name',
    'Gender'=>'Gender',
    'Male'=>'Male',
    'Sex'=>'Sex',
    'Female'=>' Female',
    'Country'=>'Country',
    'Select_Country'=>'Select Country',
    'Date_of_Birth'=>'Date of Birth',
    'Address '=>'Address ',
    'Nearest_station'=>'Nearest station',
    'Phone_Number'=>'Phone Number',
    'Class'=>'Class',
    'Opt_Subject'=>'Opt. Subject',
    'Batch'=>'Batch',
    'Student_of_Year'=>'Student of Year',
    'Student_Number'=>'Student Number',
    'Resi_id_No'=>'Resi.. id No',
    'Entry_Date'=>'Entry Date',
    'Expire_Date'=>'Expire Date',
    'Residensal_card_Time_Period'=>'Residensal card Time Period',
    'Residential_card_time_manager'=>'Residential card time manager',
    'Residenal_card_Expiry'=>'Residenal Card Expiry',
    'Part_time_job_name'=>'Part time job name',
    'Phone_where_they_works'=>'Phone where they works',
    'Address_where_they_work'=>'Address where they work',
    'Nearest_station_where_they_work'=>'Nearest station where they work',
    'Student_Note'=>'Student Note',
    'Save_Student'=>'Save Student',
    'Update_Student'=>'Update Student',
    'Select'=>'Select',
    'Date'=>'Date',
    'Time'=>'Time',
    'And'=>'and',
    'Year'=>'Year',
    'Month'=>'Month',
    'Day'=>'Day',
    'Year_month_day'=>'yyyy-mm-dd',


    'Compulsary'=>'Compulsary',
    'Optional'=>'Optional',

    /*Add Student */

    /*List Student */
    'Residential_Card_No'=>'Residential Card No',
    'Nationality'=>'Nationality/Region',
    'student_name'=>'Name (English)',
    'student_gender'=>'Gender',
    'student_dob'=>'Date of Birth',
//    'Entry_Date'=>'Entry Date',
    'student_Status'=>'Status',
    'Card_Period'=>'Resi. Card Period',
    'Card_Expire'=>'Resi. Card Expire',
    'student_remarks'=>'Remarks',
    'Student_immigration'=>'Student Immigration',

    'student_record'=>'Student Record',
    'main_reports'=>'Reports',
    'report_attendance'=>'Attendance Report',

    /*List Student */
    'Save_section'=>'Save section',

    'Save_Subject'=>'Save Subject',

    /*Attendance Language*/
    'Select_Running_Section'=>'Select Running Section',
    'Period'=>'Period',
    'Name_of_the_organization'=>'Name of the organization',
    'Students_Found'=>'Students Found',
    'Record_Not_Found'=>'Record Not Found',
    'View_All_Year'=>'View All Year',

    /* Day Translation*/
    'sunday'=>'Sun',
    'monday'=>'Mon',
    'tuesday'=>'Tue',
    'wednesday'=>'Wed',
    'thursday'=>'Thu',
    'friday'=>'Fri',
    'saturday'=>'Sat',

    /* Month Translation*/
    'Jan'=>'Jan',
    'Feb'=>'Feb',
    'Mar'=>'Mar',
    'Apr'=>'Apr',
    'May'=>'May',
    'Jun'=>'Jun',
    'Jul'=>'Jul',
    'Aug'=>'Aug',
    'Sep'=>'Sep',
    'Oct'=>'Oct',
    'Nov'=>'Nov',
    'Dec'=>'Dec',

];