<?php

return [

    'Residential_Card_No.'=>'Residential Card No',
    'Nationality'=>'Nationality/Region',
    'student_name'=>'Name (English)',
    'student_gender'=>'Gender',
    'student_dob'=>'Date of Birth',
    'Entry_Date'=>'Entry Date',
    'student_Status'=>'Status',
    'Card_Period'=>'Resi. Card Period',
    'Card_Expire'=>'Resi. Card Expire',
    'student_remarks'=>'Remarks',
];