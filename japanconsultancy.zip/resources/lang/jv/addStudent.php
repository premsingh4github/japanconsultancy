<?php

return [

    'English_Last_Name'=>'氏（漢字',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
    'English_Last_Name'=>'',
];