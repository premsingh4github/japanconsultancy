<?php

return [

    'Residential_Card_No.'=>'在留カード番号',
    'Nationality'=>'国籍・地域',
    'student_name'=>'氏名 (Japanese)',
    'student_gender'=>'性別',
    'student_dob'=>'生年月日',
    'Entry_Date'=>'入学年月日',
    'student_Status'=>'在留資格',
    'Card_Period'=>'在留期間',
    'Card_Expire'=>'在留満了日',
    'student_remarks'=>'正規生・研究 生等の種類',
];