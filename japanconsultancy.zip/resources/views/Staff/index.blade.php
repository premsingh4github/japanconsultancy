@extends('Staff.Master.master')

@section('content')
    @yield('body')
@stop
