@include('Staff.Layouts.header')
@include('Staff.Layouts.footer')
@include('Staff.Layouts.aside')

@yield('header')

@yield('aside')
@yield('content')

@yield('footer')
