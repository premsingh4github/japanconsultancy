@include('Admin.Layouts.header')
@include('Admin.Layouts.footer')
@include('Admin.Layouts.aside')

@yield('header')

@yield('aside')
@yield('content')

@yield('footer')
