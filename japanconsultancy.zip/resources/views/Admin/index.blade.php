@extends('Admin.Master.master')

@section('content')
    @yield('body')
@stop
